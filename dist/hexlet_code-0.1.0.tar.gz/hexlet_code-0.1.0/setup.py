# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/invercargill12/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/invercargill12/python-project-50/actions)\n![Python CI](https://github.com/invercargill12/python-project-50/actions/workflows/gendiff-check.yml/badge.svg)\n[![Maintainability](https://api.codeclimate.com/v1/badges/6a4b3caa2096b0ad49af/maintainability)](https://codeclimate.com/github/invercargill12/python-project-50/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/6a4b3caa2096b0ad49af/test_coverage)](https://codeclimate.com/github/invercargill12/python-project-50/test_coverage)\n\n### stylish-format json difference finder\n[![asciicast](https://asciinema.org/a/H14RS5OVq0gy871ESOJUvE8pC.svg)](https://asciinema.org/a/H14RS5OVq0gy871ESOJUvE8pC)\n\n### stylish-format yaml difference finder\n[![asciicast](https://asciinema.org/a/UNI2CDMi1QqdJfdp6KgX5SpTL.svg)](https://asciinema.org/a/UNI2CDMi1QqdJfdp6KgX5SpTL)',
    'author': 'Ivan Noev',
    'author_email': '<ivnoyev@yandex.ru>',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
