### Hexlet tests and linter status:
[![Actions Status](https://github.com/invercargill12/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/invercargill12/python-project-50/actions)
![Python CI](https://github.com/invercargill12/python-project-50/actions/workflows/gendiff-check.yml/badge.svg)
[![Maintainability](https://api.codeclimate.com/v1/badges/6a4b3caa2096b0ad49af/maintainability)](https://codeclimate.com/github/invercargill12/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/6a4b3caa2096b0ad49af/test_coverage)](https://codeclimate.com/github/invercargill12/python-project-50/test_coverage)

### stylish-format difference finder
[![asciicast](https://asciinema.org/a/H14RS5OVq0gy871ESOJUvE8pC.svg)](https://asciinema.org/a/H14RS5OVq0gy871ESOJUvE8pC)
